$(function () {
  $('#exzoom').exzoom({
    autoPlay: false,
  });
});
